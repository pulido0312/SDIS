package protocol.common;

public class MalMensajeProtocoloException extends Exception { }
