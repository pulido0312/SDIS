#!/usr/bin/bash -v

javac -d . *.java
