package helloServer;

public interface Hola extends java.rmi.Remote {
   public String dimeHola() throws java.rmi.RemoteException;
}
